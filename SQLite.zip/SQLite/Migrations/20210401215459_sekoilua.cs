﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SQLite.Migrations
{
    public partial class sekoilua : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
