﻿using System;
namespace SQLite
{
    public class Testi
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
